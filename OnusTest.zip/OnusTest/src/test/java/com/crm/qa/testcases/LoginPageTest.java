package com.crm.qa.testcases;

import java.io.File;
import java.io.IOException;

import org.testng.Assert;
import org.testng.ITestResult;
import org.testng.annotations.AfterClass;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.BeforeSuite;
import org.testng.annotations.Listeners;
import org.testng.annotations.Test;

import com.aventstack.extentreports.ExtentReports;
import com.aventstack.extentreports.ExtentTest;
import com.aventstack.extentreports.MediaEntityBuilder;
import com.aventstack.extentreports.markuputils.Markup;
import com.aventstack.extentreports.reporter.ExtentHtmlReporter;
import com.crm.qa.base.TestBase;
import com.crm.qa.pages.HomePage;
import com.crm.qa.pages.LoginPage;
import com.crm.qa.util.TestUtil;
@Listeners(com.crm.qa.util.ListnerImplementation.class)
public class LoginPageTest extends TestBase{
	LoginPage loginPage;
	HomePage homePage;
	ExtentReports extent;
	 ExtentTest logger;
	
	public LoginPageTest(){
		super();
	}
	
	@BeforeClass
	public void setUp(){
		initialization();
		loginPage = new LoginPage();	
	}
	
	@AfterClass
	public void tearDown() {
		driver.quit();
	}
	
	@Test(priority=1)
	public void loginPageTitleTest() throws InterruptedException{
		String title = loginPage.validateLoginPageTitle();
		Assert.assertEquals(title, "Workforce Dimensions");
	}
/*	
	@BeforeMethod
	public void setup()
	{
	    ExtentHtmlReporter reporter=new ExtentHtmlReporter("./Reports/extendreport1.html");
		extent = new ExtentReports();
	    extent.attachReporter(reporter);
	    logger=extent.createTest("loginPageTitleTest");
	}
	
	
	@AfterMethod
	public void tearDown(ITestResult result) throws IOException
	{
		
		if(result.getStatus()==ITestResult.SUCCESS)
		{
			logger.info("loginPageTitleTest");
			String temp=TestUtil.takeScreenshotAtEndOfTest();
			logger.addScreenCaptureFromPath(temp);			
			
		}
		else
		{
			String temp=TestUtil.takeScreenshotAtEndOfTest();
			logger.fail(result.getThrowable().getMessage(), MediaEntityBuilder.createScreenCaptureFromPath(temp).build());
		}

		
		extent.flush();
		
	}

*/
	
	
	
	
	
	
	

}
