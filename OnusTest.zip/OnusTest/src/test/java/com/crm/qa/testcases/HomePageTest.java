package com.crm.qa.testcases;

import java.io.IOException;

import org.testng.Assert;
import org.testng.ITestResult;
import org.testng.Reporter;
import org.testng.annotations.AfterClass;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Listeners;
import org.testng.annotations.Test;
import org.testng.asserts.SoftAssert;

import com.aventstack.extentreports.ExtentReports;
import com.aventstack.extentreports.ExtentTest;
import com.aventstack.extentreports.MediaEntityBuilder;
import com.aventstack.extentreports.reporter.ExtentHtmlReporter;
import com.crm.qa.base.BaseTest;
import com.crm.qa.base.TestBase;
//import com.crm.qa.pages.ContactsPage;
import com.crm.qa.pages.HomePage;
import com.crm.qa.pages.LoginPage;
import com.crm.qa.pages.TimesheetPage;
import com.crm.qa.util.TestUtil;
@Listeners(com.crm.qa.util.ListnerImplementation.class)
public class HomePageTest extends BaseTest {
	LoginPage loginPage;
	HomePage homePage;
	TestUtil testUtil;
	ExtentReports extent;
	TimesheetPage timesheetpage;
	 SoftAssert softAssert;
	//ContactsPage contactsPage;

	public HomePageTest() {
		super();
	}

	//test cases should be separated -- independent with each other
	//before each test case -- launch the browser and login
	//@test -- execute test case
	//after each test case -- close the browser
	
	@BeforeClass
	public void setUp() {
		initialization();
		loginPage = new LoginPage();	
		testUtil = new TestUtil();
		homePage = loginPage.login(prop.getProperty("username"), prop.getProperty("password"));
		 timesheetpage= new TimesheetPage();
		  softAssert = new SoftAssert();
	}


	@Test(dataProvider = "data",dataProviderClass = TestUtil.class)
	public void verifyHomePageTitleTest(String empName) throws InterruptedException{
		test = extent.createTest("Validate The  Home Page");
		Thread.sleep(2000);
		String homePageTitle = homePage.verifyHomePageTitle(empName);
		softAssert.assertEquals( homePageTitle, "https://partnersnd-034.cfn.mykronos.com/timekeeping#/timecard");
		//Assert.assertEquals(homePageTitle, "https://partnersnd-034.cfn.mykronos.com/timekeeping#/timecard");
		softAssert.assertAll();
	}
	
	
	
	
	@AfterClass
	public void tearDown(){
		driver.quit();
	}
	
/*	@BeforeMethod
	public void setup()
	{
	    ExtentHtmlReporter reporter=new ExtentHtmlReporter("./Reports/extendreport2.html");
		
	    extent = new ExtentReports();
	    extent.attachReporter(reporter);
	    logger=extent.createTest("verifyHomePageTitleTest1");
	    
	}
	
	@AfterMethod
	public void tearDown(ITestResult result) throws IOException
	{
		
			if(result.getStatus()==ITestResult.SUCCESS)
			{
				logger.info("verifyHomePageTitleTest1");
				String temp=TestUtil.takeScreenshotAtEndOfTest();
				logger.addScreenCaptureFromPath(temp);	
			}
			else
			{
				String temp=TestUtil.takeScreenshotAtEndOfTest();
				logger.fail(result.getThrowable().getMessage(), MediaEntityBuilder.createScreenCaptureFromPath(temp).build());
			}
				extent.flush();
		
	}
*/
	
}
