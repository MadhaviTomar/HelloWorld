package com.crm.qa.testcases;

import java.awt.AWTException;
import java.io.IOException;

import org.testng.Assert;
import org.testng.ITestResult;
import org.testng.Reporter;
import org.testng.annotations.AfterClass;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.AfterSuite;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.BeforeSuite;
import org.testng.annotations.Listeners;
import org.testng.annotations.Test;
import org.testng.asserts.SoftAssert;

import com.aventstack.extentreports.ExtentReports;
import com.aventstack.extentreports.ExtentTest;
import com.aventstack.extentreports.MediaEntityBuilder;
import com.aventstack.extentreports.reporter.ExtentHtmlReporter;
import com.crm.qa.base.TestBase;
import com.crm.qa.pages.HomePage;
import com.crm.qa.pages.LoginPage;
import com.crm.qa.pages.TimesheetPage;
import com.crm.qa.util.ListnerImplementation;
import com.crm.qa.util.TestUtil;
@Listeners(com.crm.qa.util.ListnerImplementation.class)
public class TimesheetPageTest extends TestBase{
	LoginPage loginPage;
	HomePage homePage;
	TimesheetPage timesheetPage;
	TestUtil testUtil;
	ListnerImplementation listnerImplimentation;
	ExtentReports extent;
	ExtentTest logger;
	SoftAssert softAssert;
	

	public TimesheetPageTest() {
		super();
	}

	@BeforeClass
	public void setUp() throws InterruptedException {
		initialization();
		testUtil = new TestUtil();
		loginPage = new LoginPage();
		homePage = loginPage.login(prop.getProperty("username"), prop.getProperty("password"));
		Thread.sleep(1000);
		timesheetPage = new TimesheetPage();
		softAssert = new SoftAssert();
		
	}



	@AfterClass
	public void tearDown() {
		driver.quit();
	}


	@Test(priority=1, dataProvider = "data",dataProviderClass = TestUtil.class)
	public void validateEmpCardPageTest(String emp) throws InterruptedException, AWTException {
	
		homePage.verifyHomePageTitle(emp);
		String empCard = timesheetPage.validateEmpCardPage();
		softAssert.assertEquals(empCard, emp);
		
		String defaultDay = timesheetPage.validateDafaultTimeFrame();
		softAssert.assertEquals(defaultDay, "Today");
		
		String todayDate = timesheetPage.validateTodayDate();
		softAssert.assertEquals(todayDate, "Tue 8/31");
		
		String dataException = timesheetPage.exceptionValidation();
		softAssert.assertEquals(dataException, "LATE_IN");
		
		String[] date = timesheetPage.getPreviousDate();
		softAssert.assertEquals(date[0], "Sun 8/08");
		softAssert.assertEquals(date[1], "Sat 8/21");
		
		String[] dateC = timesheetPage.getCurrentDate();
		softAssert.assertEquals(dateC[0], "Sun 8/22");
		softAssert.assertEquals(dateC[1], "Sat 9/04");
		
		String[] dateN = timesheetPage.getNextDate();
		softAssert.assertEquals(dateN[0], "Sun 9/05");
		softAssert.assertEquals(dateN[1], "Fri 9/17");
		softAssert.assertAll();
	}

/*	
	@Test(priority=2)
	public void validateDafaultTimeFrameTest() {
		String defaultDay = timesheetPage.validateDafaultTimeFrame();
		Assert.assertEquals(defaultDay, "Today");
}

	@Test(priority=3)
	public void validateTodayDateTest() {
		String todayDate = timesheetPage.validateTodayDate();
		Assert.assertEquals(todayDate, "Tue 8/31");
	}


	@Test(priority=4)
	public void exceptionValidationTest() throws AWTException, InterruptedException {
		String dataException = timesheetPage.exceptionValidation();
		Assert.assertEquals(dataException, "LATE_IN");	
	}


	@Test(priority = 5)
	public void clickPreviousPayPeriodTest() throws InterruptedException {
		String[] date = timesheetPage.getPreviousDate();
		Assert.assertEquals(date[0], "Sun 8/08");
		Assert.assertEquals(date[1], "Sat 8/21");
	}

	@Test(priority = 6)
	public void clickCurrentPayPeriodTest() throws InterruptedException {
		String[] date = timesheetPage.getCurrentDate();
		Assert.assertEquals(date[0], "Sun 8/22");
		Assert.assertEquals(date[1], "Sat 9/04");
	}


	@Test(priority = 7)
	public void clickNextPayPeriodTest() throws InterruptedException {
		String[] date = timesheetPage.getNextDate();
		Assert.assertEquals(date[0], "Sun 9/05");
		Assert.assertEquals(date[1], "Fri 9/17");	
	}
*/	
	
/*	@BeforeMethod
	public void setup()
	{
	    ExtentHtmlReporter reporter=new ExtentHtmlReporter("./Reports/extendreport2.html");
		
	    extent = new ExtentReports();
	    extent.attachReporter(reporter);
	    logger = extent.createTest("validateEmpCardPageTest");
	
	    
	}
	
	@AfterMethod
	public void tearDown(ITestResult result) throws IOException
	{
		
			if(result.getStatus()==ITestResult.SUCCESS)
			{
				logger.info("validateEmpCardPageTest");
				
				String temp=TestUtil.takeScreenshotAtEndOfTest();
				logger.addScreenCaptureFromPath(temp);	
			}
			else
			{
				String temp=TestUtil.takeScreenshotAtEndOfTest();
				logger.fail(result.getThrowable().getMessage(), MediaEntityBuilder.createScreenCaptureFromPath(temp).build());
			}
				extent.flush();
		
	}
*/

}
