package com.crm.qa.testcases;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;

import org.apache.poi.openxml4j.exceptions.InvalidFormatException;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.ss.usermodel.Workbook;
import org.apache.poi.ss.usermodel.WorkbookFactory;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

public class DemoTest {

	public static long PAGE_LOAD_TIMEOUT = 20;
	public static long IMPLICIT_WAIT = 20;

	public static String TESTDATA_SHEET_PATH =  "System.getProperty(\"user.dir\")+ \"/src/main/java/com/crm\"\n"
	
			+ "					+ \"/qa/testdata/Data.xlsx";

	static Workbook book;
	static Sheet sheet;
	
	public static void main() throws InvalidFormatException, IOException {
		FileInputStream fis = new FileInputStream("TESTDATA_SHEET_PATH");
		XSSFWorkbook workbook = new XSSFWorkbook(fis);
		
		String value = workbook.getSheet("Employee Details").getRow(1).getCell(1).getStringCellValue();
		System.out.println(value);
	}

	
}
