package com.crm.qa.pages;

import java.awt.AWTException;
import java.awt.Robot;
import java.awt.event.KeyEvent;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import com.crm.qa.base.TestBase;

public class TimesheetPage extends TestBase {

	@FindBy (xpath = "//button[contains(@class,'btn i dropdown')]")
	WebElement empDropdown;

	@FindBy (xpath = "//li[@id=\'combo_li0\']/a/span")
	WebElement empName;

	@FindBy (xpath="//button[contains(@class,'select-timeframe-button')]")
	WebElement dropdown;

	@FindBy (xpath="/html/body/div[1]/main/div/div/div/timecard-container/div/div/div/div[1]/div/div[2]/timecard-table/div/div/div[2]/div[1]/div/div[2]/div/div/div/div[3]/div/timecard-cell/span/span[3]/span")
	WebElement todayDate;

	@FindBy (xpath="/html/body/div[1]/main/div/div/div/timecard-container/div/div/div/div[1]/div/div[2]/timecard-table/div/div/div[2]/div[2]/div[2]/div/div/div/div[3]/div/timecard-cell/span")
	WebElement inTime;
	
	@FindBy (xpath="//i [contains(@class,'icon-k-save button-highlight')]")
	WebElement saveButton;
	
	@FindBy (xpath="//span[@id='_timeFrame']")
	WebElement defaultDay;
	
	@FindBy (xpath="/html/body/div[1]/main/div/div/div/timecard-container/div/div/div/div[1]/div/div[2]/timecard-table/div/div/div[2]/div[2]/div[2]/div/div/div/div[3]/div/timecard-cell/span/span[1]")
	WebElement dataException;

	@FindBy (xpath ="/html/body/div[1]/main/div/div/div/timecard-container/div/div/div/div[1]/div/div[2]/timecard-table/div/div/div[2]/div[1]/div/div[2]/div/div[1]/div/div[3]/div/timecard-cell/span/span[3]/span")
	WebElement firstRowDate;
	
	@FindBy (xpath = "/html/body/div[1]/main/div/div/div/timecard-container/div/div/div/div[1]/div/div[2]/timecard-table/div/div/div[2]/div[1]/div/div[2]/div/div[14]/div/div[3]/div/timecard-cell/span/span[3]/span")
	WebElement lastRowDate;

	@FindBy (xpath="(//li[contains(@class,'list-item')])[1]")
	WebElement previousPayPeriod;

	@FindBy (xpath="(//li[contains(@class,'list-item')])[2]")
	WebElement currentPayPeriod;

	@FindBy (xpath="(//li[contains(@class,'list-item')])[3]")
	WebElement nextPayPeriod;
	

	/*@FindBy (xpath="(//li[contains(@class,'list-item')])[4]")
	WebElement previousSchedulePeriod;

	@FindBy (xpath="(//li[contains(@class,'list-item')])[5]")
	WebElement currentSchedulePeriod;

	@FindBy (xpath="(//li[contains(@class,'list-item')])[6]")
	WebElement nextSchedulePeriod;

	@FindBy (xpath="(//li[contains(@class,'list-item')])[7]")
	WebElement today;

	@FindBy (xpath="(//li[contains(@class,'list-item')])[8]")
	WebElement yesterday;

	@FindBy (xpath="(//li[contains(@class,'list-item')])[9]")
	WebElement weektoDate;

	@FindBy (xpath="(//li[contains(@class,'list-item')])[10]")
	WebElement lastWeek;

	@FindBy (xpath="(//li[contains(@class,'list-item')])[11]")
	WebElement yesterdayTodayTomorrow;

	@FindBy (xpath="(//li[contains(@class,'list-item')])[12]")
	WebElement yesterdayPlus6Days;

	@FindBy (xpath="(//li[contains(@class,'list-item')])[13]")
	WebElement yesterdayMinus13Days;

	@FindBy (xpath="(//li[contains(@class,'list-item')])[14]")
	WebElement last7Days;

	@FindBy (xpath="(//li[contains(@class,'list-item')])[15]")
	WebElement last30Days;

	@FindBy (xpath="(//li[contains(@class,'list-item')])[16]")
	WebElement currentWeek;

	@FindBy (xpath="(//li[contains(@class,'list-item')])[17]")
	WebElement last4Weeks;

	@FindBy (xpath="(//li[contains(@class,'list-item')])[18]")
	WebElement last3Months;

	@FindBy (xpath="(//li[contains(@class,'list-item')])[19]")
	WebElement last90Days;

	@FindBy (xpath="(//li[contains(@class,'list-item')])[20]")
	WebElement last4Quarters;*/

	// Initializing the Page Objects:
	public TimesheetPage() {
		PageFactory.initElements(driver, this);
	}

	

	public String validateEmpCardPage() {
		Actions a = new Actions(driver);
		a.moveToElement(empDropdown).click().build().perform();
		return empName.getText();
	}
	public String validateTodayDate() {
		return	todayDate.getText();
	}
	
	public String validateDafaultTimeFrame() {
		return defaultDay.getText();
	}

	public String exceptionValidation() throws AWTException, InterruptedException {
		Thread.sleep(1000);
		inTime.click();
		Thread.sleep(1000);
		Robot r = new Robot();
		r.keyPress(KeyEvent.VK_5);
		r.keyRelease(KeyEvent.VK_5);
		r.keyPress(KeyEvent.VK_A);
		r.keyRelease(KeyEvent.VK_A);
		r.keyPress(KeyEvent.VK_M);
		r.keyRelease(KeyEvent.VK_M);
		r.keyPress(KeyEvent.VK_ENTER);
		r.keyRelease(KeyEvent.VK_ENTER);
		Thread.sleep(3000);
		saveButton.click();
		String exception = dataException.getAttribute("data-exception");
		return exception;

	}

	

	public String[] getPreviousDate() throws InterruptedException {
		Thread.sleep(2000);
		Actions a = new Actions(driver);
		a.moveToElement(dropdown).click().build().perform();
		previousPayPeriod.click();
		Thread.sleep(2000);
		String[] date = new String [2];
		date[0]=firstRowDate.getText();
		Thread.sleep(1000);
		JavascriptExecutor js = (JavascriptExecutor)driver;
    	js.executeScript("arguments[0].scrollIntoView(true);",lastRowDate);
		date[1]=lastRowDate.getText();
		js.executeScript("arguments[0].scrollIntoView(true);",firstRowDate);
		return date;
	}

	public String[] getCurrentDate() throws InterruptedException {
		Thread.sleep(2000);
		Actions a = new Actions(driver);
		a.moveToElement(dropdown).click().build().perform();
		currentPayPeriod.click();
		Thread.sleep(2000);
		String[] date = new String [2];
		date[0]=firstRowDate.getText();
		Thread.sleep(1000);
		JavascriptExecutor js = (JavascriptExecutor)driver;
    	js.executeScript("arguments[0].scrollIntoView(true);",lastRowDate);
		date[1]=lastRowDate.getText();
		js.executeScript("arguments[0].scrollIntoView(true);",firstRowDate);
		return date;
	}

	public String[] getNextDate() throws InterruptedException {
		Thread.sleep(2000);
		Actions a = new Actions(driver);
		a.moveToElement(dropdown).click().build().perform();
		nextPayPeriod.click();
		Thread.sleep(2000);
		String[] date = new String [2];
		date[0]=firstRowDate.getText();
		Thread.sleep(1000);
		JavascriptExecutor js = (JavascriptExecutor)driver;
    	js.executeScript("arguments[0].scrollIntoView(true);",lastRowDate);
    	
		date[1]=lastRowDate.getText();
		return date;
	}
}
