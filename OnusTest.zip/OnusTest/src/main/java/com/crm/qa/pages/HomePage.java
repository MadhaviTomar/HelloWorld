package com.crm.qa.pages;

//import org.openqa.selenium.Alert;
import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

import com.crm.qa.base.BaseTest;


public class HomePage extends BaseTest {

//	@FindBy(xpath = "//td[contains(text(),'User: Naveen K')]")
//	@CacheLookup
//	WebElement userNameLabel;

	@FindBy(xpath = "//a[contains(text(),'quickFind_button')]")
	WebElement quickFind_button;
	
	@FindBy(xpath = "//a[contains(text(),'employeesSearchInput')]")
	WebElement employeesSearchInput;
	
	
	// Initializing the Page Objects:
	public HomePage() {
		PageFactory.initElements(driver, this);
	}
	
	public String verifyHomePageTitle(String emp) throws InterruptedException{
		try {
			Thread.sleep(3000);
		} catch (InterruptedException e) {
			e.printStackTrace();
		}
		
		
		driver.findElement(By.xpath("//button[@id='quickFind_button']")).click();
		Thread.sleep(2000);
		driver.findElement(By.xpath("//input[@id='employeesSearchInput']")).sendKeys(emp);
		Thread.sleep(3000);
		driver.findElement(By.xpath("/html/body/div[1]/main/div/div/krn-slide-out-container/div[2]/div/div/krn-quick-find/div[2]/div[2]/div[3]/form/div[3]/div/button")).click();
		Thread.sleep(2000);
		driver.findElement(By.xpath("//*[@id='krn-slat-0-slat-area-1']/div/div/input")).click();
		Thread.sleep(2000);
		
		WebElement button = driver.findElement(By.xpath("//*[@id='goToDropdownButton']"));
		button.click();
		
		driver.findElement(By.xpath("/html/body/div[1]/main/div/div/krn-slide-out-container/div[2]/div/div/krn-quick-find/div[2]/div[3]/div[2]/div[2]/ul/li[1]/button")).click();
		
		
		
		
		Thread.sleep(2000);
		
		return driver.getCurrentUrl();
	}

	
	
	
	
	
	
	

}
