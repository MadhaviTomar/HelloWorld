package com.crm.qa.base;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.util.Date;
import java.util.Properties;
import java.util.concurrent.TimeUnit;

import org.apache.commons.io.FileUtils;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.support.events.EventFiringWebDriver;
import org.testng.ITestResult;
import org.testng.annotations.AfterClass;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.AfterSuite;
import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeSuite;
import org.testng.annotations.BeforeTest;

import com.aventstack.extentreports.ExtentReports;
import com.aventstack.extentreports.ExtentTest;
import com.aventstack.extentreports.Status;
import com.aventstack.extentreports.reporter.ExtentHtmlReporter;
import com.aventstack.extentreports.reporter.configuration.ChartLocation;
import com.aventstack.extentreports.reporter.configuration.Theme;
import com.crm.qa.util.TestUtil;
import com.crm.qa.util.WebEventListener;
import com.relevantcodes.extentreports.LogStatus;

public class BaseTest {
	   public static ExtentHtmlReporter htmlReporter;
	    public static ExtentReports extent;
	    public static ExtentTest test;
	    public static WebDriver driver;
		public static Properties prop;
		public  static EventFiringWebDriver e_driver;
		public static WebEventListener eventListener;
		
		public BaseTest()
		{
			try {
				prop = new Properties();
				FileInputStream ip = new FileInputStream(System.getProperty("user.dir")+ "/src/main/java/com/crm"
						+ "/qa/config/config.properties");
				prop.load(ip);
			} catch (FileNotFoundException e) {
				e.printStackTrace();
			} catch (IOException e) {
				e.printStackTrace();
			}
		}
		
	 @BeforeSuite
	public void Before()
	{
		 	System.out.println("I am in Before Suit");
		 	
		 	init();
		 	htmlReporter = new ExtentHtmlReporter(System.getProperty("user.dir") +"/test-output/BaseTest.html");
	        extent = new ExtentReports();
	        extent.attachReporter(htmlReporter);
	         
	        extent.setSystemInfo("OS", "Mac Sierra");
	        extent.setSystemInfo("Host Name", "Krishna");
	        extent.setSystemInfo("Environment", "QA");
	        extent.setSystemInfo("User Name", "Krishna Sakinala");
	         
	        htmlReporter.config().setChartVisibilityOnOpen(true);
	        htmlReporter.config().setDocumentTitle("AutomationTesting.in Demo Report");
	        htmlReporter.config().setReportName("My Own Report");
	        htmlReporter.config().setTestViewChartLocation(ChartLocation.TOP);
	        htmlReporter.config().setTheme(Theme.DARK);
	}
	
	 
	 
	 
	 private void init() {
		// TODO Auto-generated method stub
		 initialization();
	}




	@BeforeTest
	 public void BeforeTest()
	 {
		 System.out.println("I am in Before BeforeTest");
	 }
	 
	 @AfterMethod
	    public void getResult(ITestResult result) throws IOException
	    {
		 System.out.print("Result >> ");
	        if(result.getStatus() == ITestResult.SUCCESS)
	        {
	        	String imgName = new Date().getTime()+".png";
	        	
	            test.log(Status.PASS, "PASS");
	            test.addScreenCaptureFromPath(capture(driver,imgName));
	            //test.log(Status.PASS, "Snapshot below: " + test.addScreenCaptureFromPath(capture(driver,imgName)));
	        }
	        else if(result.getStatus() == ITestResult.FAILURE)
	        {
	            //String screenShotPath = com.qa.ExtentReportListener.GetScreenShot.capture(driver, "screenShotName");
	            //test.log(Status.FAIL, result.getThrowable());
	        	String imgName = new Date().getTime()+".png";
	        	test.log(Status.FAIL, result.getThrowable());
	            test.log(Status.FAIL, "Snapshot below: " + test.addScreenCaptureFromPath(capture(driver,imgName)));
	        	
	        }
	       // extent.endTest(test);
	    }
	 
	 @AfterSuite
	    public void endreport()
	    {
	        extent.flush();
	    }
	 
	 
	 public static String capture(WebDriver driver,String screenShotName) throws IOException
	    {
	        TakesScreenshot ts = (TakesScreenshot)driver;
	       
	        File source = ts.getScreenshotAs(OutputType.FILE);
	        String dest = System.getProperty("user.dir") +"./Screenshot/"+screenShotName+".png";
	        File destination = new File(dest);
	        FileUtils.copyFile(source, destination);        
	                     
	        return dest;
	    }
	 
	 public WebDriver getDriver()
	 {
		 if(driver == null)
		 {
			 initialization();
		 }
		 return driver;
	 }
	 
	 public static void initialization(){
			String browserName = prop.getProperty("browser");
			
			if(browserName.equals("chrome")){
				System.setProperty("webdriver.chrome.driver", "C:/chromedriver_win32/chromedriver.exe");	
				driver = new ChromeDriver(); 
			}
			else if(browserName.equals("FF")){
				System.setProperty("webdriver.gecko.driver", "/Users/naveenkhunteta/Documents/SeleniumServer/geckodriver");	
				driver = new FirefoxDriver(); 
			}
			
			
			e_driver = new EventFiringWebDriver(driver);
			// Now create object of EventListerHandler to register it with EventFiringWebDriver
			eventListener = new WebEventListener();
			e_driver.register(eventListener);
			driver = e_driver;
			
			driver.manage().window().maximize();
			
			driver.manage().deleteAllCookies();
			driver.manage().timeouts().pageLoadTimeout(TestUtil.PAGE_LOAD_TIMEOUT, TimeUnit.SECONDS);
			driver.manage().timeouts().implicitlyWait(TestUtil.IMPLICIT_WAIT, TimeUnit.SECONDS);
			
			driver.get(prop.getProperty("url"));
//			try {
//				Thread.sleep(30);
//			} catch (InterruptedException e) {
//				// TODO Auto-generated catch block
//				e.printStackTrace();
//			}
			
		}
	    
}
